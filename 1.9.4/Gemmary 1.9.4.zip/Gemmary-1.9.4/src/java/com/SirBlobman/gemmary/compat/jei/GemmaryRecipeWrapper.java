package com.SirBlobman.gemmary.compat.jei;

import mezz.jei.api.recipe.BlankRecipeWrapper;

public abstract class GemmaryRecipeWrapper extends BlankRecipeWrapper {}