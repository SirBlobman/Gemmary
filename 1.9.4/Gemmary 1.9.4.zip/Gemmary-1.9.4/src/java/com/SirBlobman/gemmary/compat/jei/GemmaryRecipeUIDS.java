package com.SirBlobman.gemmary.compat.jei;

public class GemmaryRecipeUIDS 
{
	private GemmaryRecipeUIDS() {}
	
	public static final String COMPRESSING = "gemmary.compressing";
	public static final String HYDRATING = "gemmary.hydrating";
	
	public static final String DESCRIPTION = "gemmary.description";
}
