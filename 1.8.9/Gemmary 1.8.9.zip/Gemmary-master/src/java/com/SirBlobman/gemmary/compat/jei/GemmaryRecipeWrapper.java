package com.SirBlobman.gemmary.compat.jei;

import mezz.jei.api.recipe.BlankRecipeWrapper;

public class GemmaryRecipeWrapper extends BlankRecipeWrapper
{
	
}
