package com.SirBlobman.gemmary.compat.jei;

public class GemmaryRecipeCategoryUid 
{
	private GemmaryRecipeCategoryUid()
	{
		
	}
	public static final String COMPRESSING = "gemmary.compressing";
	public static final String HYDRATING = "gemmary.hydrating";
}
